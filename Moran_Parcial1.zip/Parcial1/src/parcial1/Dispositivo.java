
package parcial1;

public abstract class Dispositivo {
    protected Integer nroserie;

    public Dispositivo(Integer nroserie) {
        this.nroserie = nroserie;
    }
    
    public void Encender(){
        
    }
    public void Apagar(){
        
    }
    public void MostrarInfo(){
        
    }
}

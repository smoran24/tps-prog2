
package tp1_ej1;

public class OPERACIONES {
    float atrib1, atrib2, result;
    float suma(float param1, float param2){
        this.result=param1+param2;
        return(result);
    }
    float resta(float param1, float param2){
        this.result=param1-param2;
        return(result);
    }
    float producto(float param1, float param2){
        this.result=param1*param2;
        return(result);
    }
    float cociente(float param1, float param2){
        this.result=param1/param2;
        return(result);
    }
}


package pizzeriabeto;

import java.util.List;

public class Comanda {
    private Mozo mozo;
    private int mesa;
    private String[] estado = {"Preparando", "Listo para servir", "Entregado", "Cobrado"};
    private List<MenuItem> items;
    
    public void agregarItem(){
        
    }
    public void removerItem(){
        
    }
    
}

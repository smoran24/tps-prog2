
package pizzeriabeto;

public class MenuItem {
    private String nombre;
    private float precio;
    
    /*public aumentarPrecio(){
        
    }*/
}


package parcial1;

public class UnidadModular {
    private int cantidadcircuitos;
}


package pizzeriabeto;

public class PizzeriaBeto {

    public static void main(String[] args) {
    }
    
}

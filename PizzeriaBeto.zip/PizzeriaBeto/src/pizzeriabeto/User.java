
package pizzeriabeto;

public class User {
    private String nombre;
    private String email;
    private String password;
    
    public void iniciarSesion(){
        
    }
    public void cerrarSesion(){
        
    }
}

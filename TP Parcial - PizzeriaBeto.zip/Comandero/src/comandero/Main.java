
package comandero;
/*Integrantes del grupo: 
Aguilar, Matías
Fernández, Santiago
Gonzalez del Solar, Francisco
Morán, Sebastián

La contraseña para el usuario Empleado es 123
*/
public class Main {
  public static void main(String[] args) {

    Menu.menuPrincipal();
    
  }
}

package pizzeriabeto;

public class Chef {
    public User usuario;
    
}

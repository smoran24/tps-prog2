
package pizzeriabeto;

import java.util.List;

public class Cocina {
    public List <Comanda> comandas;
    public Chef chef;
    
    public void aceptar(Comanda p_comanda){
        
    }
    public void finalizar (Comanda p_comanda){
        
    }
}

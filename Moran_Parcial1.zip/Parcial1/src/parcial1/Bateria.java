
package parcial1;

public class Bateria {
    private double amperaje;
    private double voltaje;
    private String nombremodelo;
}

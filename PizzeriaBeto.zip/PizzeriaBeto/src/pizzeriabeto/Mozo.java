
package pizzeriabeto;

import java.util.List;

public class Mozo {
    private User usuario;
    public String nombre;
    public Menu menu;
    public List<Integer> mesas;
    
    public Comanda tomarPedido(){
        
    }
    public void enviarACocina(){
        
    }
    public void entregarPedido(){
        
    }
    public void cobrarPedido(){
        
    }
}

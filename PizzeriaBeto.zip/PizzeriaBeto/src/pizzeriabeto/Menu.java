
package pizzeriabeto;

import java.util.List;

public class Menu {
    public List <MenuItem> items;
    
    public void agregarItem(){
        
    }
    public void removerItem(){
        
    }
}
